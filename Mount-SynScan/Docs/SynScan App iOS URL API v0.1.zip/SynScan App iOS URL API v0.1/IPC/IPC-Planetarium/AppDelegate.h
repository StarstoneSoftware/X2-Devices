//
//  AppDelegate.h
//  IPC-Planetarium
//
//  Created by Skywatcher Application Developer on 2017-05-18.
//  Copyright © 2017 SW. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

