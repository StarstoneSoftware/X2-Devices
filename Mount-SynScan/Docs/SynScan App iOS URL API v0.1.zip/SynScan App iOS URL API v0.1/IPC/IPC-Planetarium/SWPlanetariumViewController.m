//
//  SWPlanetariumViewController.m
//  IPC-Planetarium
//
//  Created by Skywatcher Application Developer on 2017-05-18.
//  Copyright © 2017 SW. All rights reserved.
//

#import "SWPlanetariumViewController.h"
#import "NSURL+QueryDictionary.h"

@interface SWPlanetariumViewController ()

@property (weak, nonatomic) IBOutlet UILabel *lbCanOpenUrl;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segGoToTarget;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segRA;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segDec;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segCoord;

- (IBAction)actGoTo:(id)sender;

@end

#define SYNSCAN_GOTO_URL         @"com-skywatcher-synscan://local/goto"
#define MYAPP_RETURN_URL         @"com-skywatcher-ipc-planetarium://local/goto-return"
@implementation SWPlanetariumViewController

//---------------------------------------------------------------------------
#pragma mark - life-cycle
//---------------------------------------------------------------------------
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated {
    [NSNotificationCenter.defaultCenter addObserver: self selector: @selector(refreshCanHandle)
                                               name: UIApplicationDidBecomeActiveNotification object: nil];
}

- (void)viewWillDisappear:(BOOL)animated {
    [NSNotificationCenter.defaultCenter removeObserver:self name:UIApplicationDidBecomeActiveNotification object: nil];
}

//---------------------------------------------------------------------------
#pragma mark - actions
//---------------------------------------------------------------------------
- (void)refreshCanHandle {
    BOOL canOpen = [UIApplication.sharedApplication canOpenURL: [NSURL URLWithString: SYNSCAN_GOTO_URL] ];
    self.lbCanOpenUrl.text = canOpen ? @"YES" : @"NO";
}

//Get URL that will open this app, with some context attached
static NSURL* getReturnURL(NSString *context_unencoded) {
    NSDictionary *queries = [NSDictionary dictionaryWithObjectsAndKeys:
                             context_unencoded , @"context",
                             nil
                             ];
    NSURL *retUrlBase = [NSURL URLWithString: MYAPP_RETURN_URL];
    NSURL *retUrl = [retUrlBase uq_URLByAppendingQueryDictionary: queries];
    return retUrl;
}

- (IBAction)actGoTo:(id)sender {
    // URL parameters.
    // Note They are not url-encoded
    NSString *str_name = [self.segGoToTarget titleForSegmentAtIndex:
                          self.segGoToTarget.selectedSegmentIndex];
    NSString *str_coordType = self.segCoord.selectedSegmentIndex==0 ? @"rd_jnow" : @"rd_j2000";
    double raDeg = self.segRA.selectedSegmentIndex * 6 * 15;
    double decDeg = (self.segDec.selectedSegmentIndex - 2) * -40;
    NSString *str_raDeg  = [NSString stringWithFormat: @"%.6f", raDeg];
    NSString *str_decDeg = [NSString stringWithFormat: @"%.6f", decDeg];
    NSString *str_returnUrl = [getReturnURL(str_name) absoluteString];
    
    // make url
    NSURL *baseUrl = [NSURL URLWithString: SYNSCAN_GOTO_URL];
    NSDictionary *queries = [NSDictionary dictionaryWithObjectsAndKeys:
                             str_name        , @"name",
                             str_coordType   , @"coordType",
                             str_raDeg       , @"coord1",
                             str_decDeg      , @"coord2",
                             str_returnUrl   , @"returnUrl",
                             nil
                             ];
    NSURL *url = [baseUrl uq_URLByAppendingQueryDictionary: queries];
    
    //
    [UIApplication.sharedApplication openURL: url];
}

@end
