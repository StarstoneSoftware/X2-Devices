//
//  SWMainViewController.h
//  IPC
//
//  Created by Skywatcher Application Developer on 2017-05-18.
//  Copyright © 2017 SW. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SWMainViewController : UITabBarController

- (void) handleURL:(NSURL*)url;

@end
