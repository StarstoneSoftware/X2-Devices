//
//  main.m
//  IPC-SynScan
//
//  Created by Skywatcher Application Developer on 2017-05-18.
//  Copyright © 2017 SW. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
