//
//  SWGoToViewController.m
//  IPC
//
//  Created by Skywatcher Application Developer on 2017-05-18.
//  Copyright © 2017 SW. All rights reserved.
//

#import "SWGoToViewController.h"
#import "NSURL+QueryDictionary.h"

//---------------------------------------------------------------------------
#pragma mark - SWGoToReq
//---------------------------------------------------------------------------
@interface SWGoToReq : NSObject

@property (nonatomic) NSString *name;
@property (nonatomic) NSURL *returnURL;
@property (nonatomic) int goToSecLeft;

@end;

@implementation SWGoToReq
@end

//---------------------------------------------------------------------------
#pragma mark - SWGoToViewController
//---------------------------------------------------------------------------
@interface SWGoToViewController () {}

@property (weak, nonatomic) IBOutlet UILabel *lbGoToStatus;
@property (weak, nonatomic) IBOutlet UILabel *lbGoToCountDown;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segResult;

@property (nonatomic) NSTimer *goToTimer;
@property (nonatomic) SWGoToReq *goToReq;

@end

@implementation SWGoToViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

- (void) doGoToWithName:(NSString*)name returnUrl:(NSURL*)url {
    self.goToReq = [[SWGoToReq alloc] init];
    self.goToReq.name = name;
    self.goToReq.returnURL = url;
    self.goToReq.goToSecLeft = 5;
    
    self.lbGoToStatus.text = [NSString stringWithFormat: @"Going to %@ ...", name];
    self.lbGoToCountDown.text = nil;
    [self.goToTimer invalidate];
    self.goToTimer = [NSTimer scheduledTimerWithTimeInterval: 1.0
                                                      target: self
                                                    selector: @selector(handleGoToTimer:)
                                                    userInfo: nil
                                                     repeats: YES];
}

- (void) handleGoToTimer:(id)userInfo {
    // update count
    self.goToReq.goToSecLeft--;
    self.lbGoToCountDown.text = [NSString stringWithFormat: @"%d", self.goToReq.goToSecLeft];
    
    // go to continues
    if (self.goToReq.goToSecLeft > 0)
        return;
    
    // go to ends
    [self.goToTimer invalidate];
    self.lbGoToStatus.text = [NSString stringWithFormat: @"Going to %@ finished", self.goToReq.name];
    
    // set result in return URL
    NSString *result = [self.segResult titleForSegmentAtIndex: self.segResult.selectedSegmentIndex];
    NSDictionary *resultDict = [NSDictionary dictionaryWithObjectsAndKeys: result, @"result", nil];
    
    // open
    [UIApplication.sharedApplication openURL: [self.goToReq.returnURL uq_URLByAppendingQueryDictionary: resultDict]];
}

@end
