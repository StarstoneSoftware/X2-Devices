//
//  SWMainViewController.m
//  IPC
//
//  Created by Skywatcher Application Developer on 2017-05-18.
//  Copyright © 2017 SW. All rights reserved.
//

#import "SWMainViewController.h"
#import "SWGoToViewController.h"
#import "NSURL+QueryDictionary.h"

@interface SWMainViewController ()

@end

@implementation SWMainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

//---------------------------------------------------------------------------
#pragma mark actions
//---------------------------------------------------------------------------
- (void) handleURL:(NSURL*)url {
    
    NSURLComponents *components = [NSURLComponents componentsWithURL:url resolvingAgainstBaseURL:YES];
    
    //go to
    BOOL isGoTo = [components.path isEqualToString: @"/goto"];
    if (isGoTo) {
        NSDictionary *queries = [url uq_queryDictionary];
        NSString *name = [queries objectForKey: @"name"];
        if (! name)
            return;
        NSURL *returnUrl = [NSURL URLWithString: [queries objectForKey: @"returnUrl"]];
        
        //vc
        self.selectedIndex = 1;
        [(SWGoToViewController*) self.selectedViewController doGoToWithName: name returnUrl: returnUrl];
    }
}

@end
